let files = [];
let selectedIndex = -1;
let currentOp = "merge";

const input = document.getElementById("fileInput");
const drop = document.getElementById("dropZone");

input.addEventListener("change", e => addFiles([...e.target.files]));
drop.addEventListener("dragover", e => {e.preventDefault(); drop.style.borderColor="#6ee7b7"});
drop.addEventListener("dragleave", () => drop.style.borderColor="#334552");
drop.addEventListener("drop", e => {
  e.preventDefault();
  drop.style.borderColor="#334552";
  addFiles([...e.dataTransfer.files].filter(f => f.name.toLowerCase().endsWith(".pdf")));
});

function addFiles(newFiles){
  files.push(...newFiles.filter(f => f.name.toLowerCase().endsWith(".pdf")));
  renderFiles();
  if(selectedIndex < 0 && files.length) selectFile(0);
}

function renderFiles(){
  document.getElementById("fileCount").textContent = `${files.length} file${files.length===1?"":"s"}`;
  const list = document.getElementById("fileList");
  list.innerHTML = "";
  files.forEach((f,i)=>{
    const row=document.createElement("div");
    row.className="file-row"+(i===selectedIndex?" selected":"");
    row.innerHTML=`
      <span class="file-name" title="${escapeHtml(f.name)}">${escapeHtml(f.name)}</span>
      <span class="file-actions">
        <button onclick="moveFile(${i},-1)">↑</button>
        <button onclick="moveFile(${i},1)">↓</button>
        <button onclick="removeFile(${i})">✕</button>
      </span>`;
    row.onclick=(e)=>{if(!e.target.closest("button"))selectFile(i)};
    list.appendChild(row);
  });
}

function selectFile(i){
  if(!files[i]) return;
  selectedIndex=i;
  renderFiles();
  loadPreview(files[i]);
}

function moveFile(i,dir){
  const j=i+dir;
  if(j<0||j>=files.length)return;
  [files[i],files[j]]=[files[j],files[i]];
  if(selectedIndex===i) selectedIndex=j;
  else if(selectedIndex===j) selectedIndex=i;
  renderFiles();
}

function removeFile(i){
  files.splice(i,1);
  if(!files.length){selectedIndex=-1; clearPreview();}
  else if(selectedIndex>=files.length) selectedIndex=files.length-1;
  renderFiles();
  if(selectedIndex>=0) loadPreview(files[selectedIndex]);
}

function clearAll(){
  files=[]; selectedIndex=-1; renderFiles(); clearPreview(); showMessage("");
}

function clearPreview(){
  document.getElementById("previewArea").className="preview-empty";
  document.getElementById("previewArea").textContent="Select a PDF to preview its pages.";
  document.getElementById("previewName").textContent="";
}

async function loadPreview(file){
  const fd=new FormData();
  fd.append("file",file);
  showMessage("Loading preview...");
  try{
    const res=await fetch("/preview",{method:"POST",body:fd});
    const data=await res.json();
    if(!res.ok) throw new Error(data.error);
    document.getElementById("previewName").textContent="• "+data.filename;
    const area=document.getElementById("previewArea");
    area.className="preview-pages";
    area.innerHTML="";
    data.pages.forEach(p=>{
      const div=document.createElement("div");
      div.className="thumb";
      div.innerHTML=`<img alt="Page ${p.page}"><div class="thumb-label">Page ${p.page}</div>`;
      // Fetch page image through POST is required; replace image with blob.
      const fd2=new FormData(); fd2.append("file",file); fd2.append("page",p.page);
      fetch("/preview-page",{method:"POST",body:fd2}).then(r=>r.blob()).then(blob=>{
        div.querySelector("img").src=URL.createObjectURL(blob);
      });
      area.appendChild(div);
    });
    showMessage("");
  }catch(e){showMessage(e.message,true)}
}

function selectOp(op,btn){
  currentOp=op;
  document.querySelectorAll(".op").forEach(x=>x.classList.remove("active"));
  btn.classList.add("active");
  document.querySelectorAll(".controls").forEach(x=>x.classList.add("hidden"));
  document.getElementById(op==="word"?"wordControls":op+"Controls").classList.remove("hidden");
}

function needFile(){
  if(!files.length){showMessage("Please add a PDF first.",true);return false}
  return true;
}
function oneFile(){
  if(!needFile()) return false;
  if(selectedIndex<0){showMessage("Select a PDF first.",true);return false}
  return true;
}

async function downloadResponse(url,fd){
  showMessage("Processing...");
  try{
    const r=await fetch(url,{method:"POST",body:fd});
    if(!r.ok){
      let d={}; try{d=await r.json()}catch{}
      throw new Error(d.error||"Operation failed.");
    }
    const blob=await r.blob();
    const cd=r.headers.get("Content-Disposition")||"";
    let name="B4DCYBER_Output.pdf";
    const m=cd.match(/filename="?([^"]+)"?/); if(m) name=m[1];
    const a=document.createElement("a");
    a.href=URL.createObjectURL(blob); a.download=name; a.click();
    URL.revokeObjectURL(a.href);
    showMessage("Done. Download started.");
  }catch(e){showMessage(e.message,true)}
}

function mergePDFs(){
  if(files.length<2){showMessage("Select at least two PDF files.",true);return}
  const fd=new FormData();
  files.forEach(f=>fd.append("files",f));
  downloadResponse("/merge",fd);
}

function extractPDF(){
  if(!oneFile())return;
  const value=document.getElementById("extractPages").value.trim();
  if(!value){showMessage("Enter pages to extract.",true);return}
  const fd=new FormData();
  fd.append("file",files[selectedIndex]); fd.append("pages",value);
  downloadResponse("/extract",fd);
}

function deletePDF(){
  if(!oneFile())return;
  const value=document.getElementById("deletePages").value.trim();
  if(!value){showMessage("Enter pages to delete.",true);return}
  const fd=new FormData();
  fd.append("file",files[selectedIndex]); fd.append("pages",value);
  downloadResponse("/delete",fd);
}

function rotatePDF(){
  if(!oneFile())return;
  const fd=new FormData();
  fd.append("file",files[selectedIndex]);
  fd.append("pages",document.getElementById("rotatePages").value.trim());
  fd.append("angle",document.getElementById("rotateAngle").value);
  downloadResponse("/rotate",fd);
}

function pdfToWord(){
  if(!oneFile())return;
  const fd=new FormData(); fd.append("file",files[selectedIndex]);
  downloadResponse("/pdf-to-word",fd);
}

function showMessage(msg,error=false){
  const el=document.getElementById("message");
  el.textContent=msg;
  el.style.color=error?"#ff8c8c":"#8df0c4";
}
function escapeHtml(s){
  return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}

function ocrPDF(){
  if(!oneFile())return;
  const fd=new FormData();
  fd.append("file",files[selectedIndex]);
  fd.append("pages",document.getElementById("ocrPages").value.trim());
  downloadResponse("/ocr",fd);
}
